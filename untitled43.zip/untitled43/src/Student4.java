public class Student4 {
    private String name;
    private int course;
    private int age;

    public Student4(String name, int course, int age) {
        this.name = name;
        this.course = course;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getCourse() {
        return course;
    }

    public int getAge() {
        return age;
    }
}
