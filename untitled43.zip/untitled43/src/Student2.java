public class Student2 {
    private String name;
    private int grade;

    public Student2(String name, int grade) {
        this.name = name;
        this.grade = grade;
    }

    public String getName() {
        return name;
    }

    public int getGrade() {
        return grade;

    }
}